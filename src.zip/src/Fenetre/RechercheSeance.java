/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import DAO.SeanceDAO;
import java.awt.FlowLayout;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class RechercheSeance extends JFrame implements ActionListener{
    private final JButton ok,ok2;
    private final JPanel p1, p2,p3;
    private final JLabel research, research_id;
    private final JTextField recherche, id;
    private JTable table;
    
    public RechercheSeance(){
    
        super("Recherche de Seance");
        
        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 650, 400);
        setResizable(true);
        setVisible(true);
        
        //creation des bouttons
        ok = new JButton("Recherche");
        ok2 = new JButton("Recherche");
        // creation des labels
        research = new JLabel("Recherche un seance avec une date : ", JLabel.CENTER);
        research_id = new JLabel("Séléctionnez l'Id de la seance voulu: ", JLabel.CENTER);
        
        // creation des panneaux
        p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        
        recherche = new JTextField();
        recherche.setPreferredSize(new Dimension(150,30));
        id = new JTextField();
        id.setPreferredSize(new Dimension(150,30));
       
     
        table=null;
        p1.add(research);
        p1.add(recherche);
        p1.add(ok);
        
        
        ok.addActionListener(this);
        ok2.addActionListener(this);
        
        //mise en place des panels
        add("North", p1);
        add("Center", p2);
        add("South", p3);
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent evet) {
        Object source = evet.getSource();
        //System.out.println(ok.getModel().isPressed());
        //Action recherche par date lancée
        if (ok.getModel().isPressed() == false) 
        {
            Object source2 = evet.getSource();
            SeanceDAO seancedao= new SeanceDAO();
            int validite = seancedao.testdate(recherche.getText());
            if (validite == 1)
            {
                //System.out.println("Date Valide");
                table=seancedao.finddate(recherche.getText());
                p2.add(table);
                p3.add(research_id);
                p3.add(id);
                p3.add(ok2);
                ok2.addActionListener(this);

                //Action recherche par Id
                if (source == ok2)
                {
                    ModificationSeance modificationseance= new ModificationSeance(Integer.parseInt(id.getText()));
                    setVisible(false);
                }
            }
            else 
            {
                System.out.println("Date Invalide");
                setVisible(false);
                MauvaiseRechercheSeance con = new MauvaiseRechercheSeance();
            }
        }
    }
    
}
 