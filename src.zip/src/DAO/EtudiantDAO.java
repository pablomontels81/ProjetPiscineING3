/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Etudiant;
import projet_java.Utilisateur;


/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class EtudiantDAO extends Dao<Etudiant>
{

    public EtudiantDAO() 
    {
        super();
    }
    public Etudiant find(int id_utilisateur) 
    {
    Etudiant eleve = new Etudiant();
    Utilisateur utilisateur = new Utilisateur();
    UtilisateurDAO utilisateurDao = new UtilisateurDAO();
    
    //Vérification si l'id existent
    utilisateur = utilisateurDao.find(id_utilisateur);
      
    try {
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM etudiant WHERE Id_Utilisateur = " + id_utilisateur);
      if(result.first())
      {
          eleve = new Etudiant(id_utilisateur, utilisateur.getEmail(), utilisateur.getPsswd(), utilisateur.getNom(), utilisateur.getPrenom(), utilisateur.getDroit(), result.getInt("Numero"), result.getInt("Id_Groupe"));    
      }
             
        }catch (SQLException e) 
        {
            e.printStackTrace();
        }
    return eleve;
    }
    
    public void add(Etudiant p_etudiant) throws SQLException
    {
        int p_IdEtudiant;
        p_IdEtudiant = p_etudiant.getId();
        int p_IdGroupe = p_etudiant.getIdGroupe();
        int p_numero = p_etudiant.getNumero();
        this.Connection.createStatement().executeUpdate("INSERT INTO enseignant (Id_Utilisateur, Id_Groupe, Numero) VALUES ('"+p_IdEtudiant+"','"+p_IdGroupe+"','"+p_numero+"');");
    }
}
