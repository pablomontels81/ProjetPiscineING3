/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Groupe {
    
    protected int id_groupe ;
    protected int id_promotion;
    protected String nom;
    
    //Constructeurs sans paramètres 
    public Groupe()
    {
        id_groupe = 0;
        id_promotion = 0; 
        nom = null;
    }
 
    //constructeur avec paramètres 
    public Groupe(int p_id, String p_nom, int p_promotion)
    {
        id_groupe = p_id;
        id_promotion = p_promotion; 
        nom = p_nom;
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Groupe() 
    {
      return id_groupe;
    }
    public int getId_Promotion() 
    {
      return id_promotion;
    }
    public String getNom() 
    {
      return nom;
    } 
    
    /*** Setteurs
     * @param id ***/
    public void setId_Groupe(int id) 
    {
      this.id_groupe = id;
    }
    public void setId_Promotion(int id) 
    {
      this.id_promotion = id;
    }
    public void setNom(String nom) 
    {
      this.nom = nom;
    }
}