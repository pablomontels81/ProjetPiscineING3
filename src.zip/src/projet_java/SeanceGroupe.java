/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class SeanceGroupe {
    
    protected int id_seance ;
    protected int id_groupe ;
    
    //Constructeurs sans paramètres 
    public SeanceGroupe()
    {
        id_seance = 0;
        id_groupe = 0;
    }
 
    //constructeur avec paramètres 
    public SeanceGroupe(int p_id1, int p_id2)
    {
        id_seance = p_id1;
        id_groupe = p_id2;
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Seance() 
    {
      return id_seance;
    }
    public int getId_Groupe() 
    {
      return id_groupe ;
    }
    
    /*** Setteurs
     * @param id ***/
    public void setId_Seance(int id) 
    {
      this.id_seance = id;
    }
    public void setId_Groupe(int id) 
    {
      this.id_groupe = id;
    }
}