/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Site;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class SiteDAO extends Dao<Site> {
  
  public SiteDAO() 
  {
    super();
  } 
  @Override
  public Site find(int id) 
  {
    Site site = new Site();      

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM site WHERE Id_Site = " + id);
            if(result.first())
            {
                site = new Site(id,result.getString("Nom")); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return site;
  }
  
  public void add(Site p_site) throws SQLException
    {
        String p_nom = p_site.getNom();
        this.Connection.createStatement().executeUpdate("INSERT INTO site ( Nom) VALUES ('"+p_nom+"');");
    }
}
