/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;


import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.util.*;
import javax.swing.JLabel;
import javax.swing.JTable;
import projet_java.Seance;
import java.text.SimpleDateFormat;
//import java.util.Date;
/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class SeanceDAO extends Dao<Seance>{
    
  public SeanceDAO() 
  {
    super();
  } 
  @Override
  public Seance find(int id) 
  {
    Seance seance = new Seance();
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance WHERE Id_Seance = " + id);
            if(result.first())
            {
                seance = new Seance(id, result.getInt("Semaine"), result.getDate("Date"), result.getTime("Heure_Debut"), result.getTime("Heure_Fin"), result.getInt("Etat"), result.getInt("Id_Cours"), result.getInt("Id_Type")); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return seance;
  }
  
    /**
     *
     * @param p_semaine
     * @param p_date
     * @param p_heuredebut
     * @param p_heurefin
     * @param p_etat
     * @param p_IdCours
     * @param p_IdType
     * @throws SQLException
     */
    public void add(int p_semaine, Date p_date, Time p_heuredebut, Time p_heurefin, int p_etat, int p_IdCours, int p_IdType) throws SQLException
    {
        this.Connection.createStatement().executeUpdate("INSERT INTO seance ( Semaine, Date, Heure_Debut, Heure_Fin, Etat, Id_Cours, Id_Type) VALUES ('"+p_semaine+"','"+p_date+"','"+p_heuredebut+"','"+p_heurefin+"','"+p_etat+"','"+p_IdCours+"','"+p_IdType+"');");
    }
     public void update(Seance p_seance) 
  {
    try {
          this.Connection.createStatement().executeUpdate("UPDATE seance SET  Semaine='"+p_seance.getSemaine()+"', Date='"+p_seance.getDate()+"', Heure_Debut='"+p_seance.getHeure_Debut()+"', Heure_Fin='"+p_seance.getHeure_Fin()+"', Etat='"+p_seance.getEtat()+"', Id_Cours='"+p_seance.getId_Cours()+"', Id_Type='"+p_seance.getId_Type()+"'WHERE Id_Seance='"+p_seance.getId_Seance()+"';");
            
    } catch (SQLException e) 
            {
                e.printStackTrace();
            }
  }
     
     public int testdate(String date){
         //Déclaration Variable
         String dateformat = "yyyy-MM-dd";
         int valide = 1;
         
         //Test si Date valide (bon format)
         SimpleDateFormat sdf;
         sdf = new SimpleDateFormat(dateformat);
         sdf.setLenient(false);
         java.util.Date datetest = null;
         
         try {
            datetest = sdf.parse(date);
        } catch (ParseException ex) {
            // la chaîne ne correspond pas à une date valide
            valide = 0;
            
        }
        
         
      return valide; 
     }
     
     public JTable finddate(String date){
          Seance seance = new Seance();
          JTable table = new JTable();
          Date.valueOf(date);
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance WHERE Date = '" + date+"';");
            ResultSetMetaData resultMeta = result.getMetaData();
            //création d'un tableau de type String de "getcolumncount" colonnes
            Object[] columnNames = new String[resultMeta.getColumnCount()];
                    //new String[resultMeta.getColumnCount()];
            for (int i = 1; i <= resultMeta.getColumnCount(); i++)
            {   
                columnNames[i-1]=resultMeta.getColumnName(i);//rcupération du nom de chaques colonnes
                
            }
            //System.out.println(Arrays.toString(columnNames));
            List<Object[]> donnee = new ArrayList<>();
            donnee.add(columnNames);
            while(result.next()) 
            {
             // on créé un tableau pour stocker la ligne courante
             Object[] ligne = new Object[resultMeta.getColumnCount()];
            for (int i = 1; i <= resultMeta.getColumnCount(); i++) 
                {
                    ligne[i-1]=result.getObject(i);
                }
            donnee.add(ligne); // on ajoute la ligne à la liste
            }
            
         table = new JTable( donnee.stream().toArray(Object[][]::new), columnNames); // on convertit la liste en tableau pour appeler le constructeur et créer une seule JTable

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    return table;
     }
    /* public void modifier(){
         Seance seance1 = new Seance();
        seance1.setId_Seance(1);
        seance1.setId_Cours(1);
        seance1.setId_Type(1);
        seance1.setSemaine(22);
        String date = "2020-05-22";
        seance1.setDate(Date.valueOf(date));
        String t1 = "16:40:00";
        seance1.setHeure_Debut(Time.valueOf(t1));
        String t2 = "18:35:00";
        System.out.println(seance1.getHeure_Fin());
        seance1.setEtat(2);
        
        SeanceDAO seanceDao = new SeanceDAO();
        
        seanceDao.update(seance1);
     }*/

}
