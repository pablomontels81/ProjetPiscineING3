/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Enseignant {
    
    protected int id_enseignant ;
    protected int id_cours;
    
    //Constructeurs sans paramètres 
    public Enseignant()
    {
        id_enseignant = 0;
        id_cours = 0;
    }
 
    //constructeur avec paramètres 
    public Enseignant(int p_id1, int p_id2)
    {
        id_enseignant = p_id2;
        id_cours = p_id1;
    }
    
     /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Enseignant() 
    {
      return id_enseignant;
    }
    public int getId_Cours() 
    {
      return id_cours;
    }
    
    /*** Setteurs
     * @param id ***/
    public void setId_Enseignant(int id) 
    {
      this.id_enseignant = id;
    }
    public void setId_Cours(int id) 
    {
      this.id_cours = id;
    }
}