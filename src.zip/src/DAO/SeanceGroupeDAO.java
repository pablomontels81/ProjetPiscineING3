/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import projet_java.Groupe;
import projet_java.Seance;
import projet_java.SeanceGroupe;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public abstract class SeanceGroupeDAO extends Dao<SeanceGroupe> {
  
  public SeanceGroupeDAO() 
  {
    super();
  } 

    /**
     *
     * @param id_seance
     * @param id_groupe
     * @return
     */

  public SeanceGroupe find2(int id_seance, int id_groupe) 
  {
    SeanceGroupe seancegroupe = new SeanceGroupe();
    Seance seance = new Seance();
    SeanceDAO seanceDao = new SeanceDAO();
    Groupe groupe = new Groupe();
    GroupeDAO groupeDao = new GroupeDAO();
    
    //Vérification si les deux id existent
    seance = seanceDao.find(id_seance);
    groupe = groupeDao.find(id_groupe);

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_groupe WHERE Id_Seance = '" + id_seance + "'AND Id_Groupe = '" + id_groupe + "';");
            if(result.first())
            {
                seancegroupe = new SeanceGroupe(seance.getId_Seance(), groupe.getId_Groupe()); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return seancegroupe;
  }
  
  public void add(int p_IdSeance,String p_NomGroupe) throws SQLException
    {
        int testvalidite;
        int p_IdGroupe = findIdGroupe(p_NomGroupe);
        testvalidite = testgroupevalide(p_IdGroupe, p_IdSeance);
        if(testvalidite != 1)
        {
            this.Connection.createStatement().executeUpdate("INSERT INTO seance_groupe ( Id_Seance, Id_Groupe) VALUES ('"+p_IdSeance+"','"+p_IdGroupe+"');");
        }
    }
  
  public void modifier(String p_NomGroupe, int p_IdSeance) throws SQLException
  {
      //récupération de l'ID de la salle 
      int p_IdGroupe;
      int testvalidite;
      p_IdGroupe = findIdGroupe(p_NomGroupe);
      testvalidite = testgroupevalide(p_IdGroupe, p_IdSeance);
      
      //Vérification si le couple existe
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_groupe WHERE Id_Seance = '" + p_IdSeance + "'AND Id_Groupe = '" + p_IdGroupe + "';");
      //Le couple Seance Enseignant existe
      if(result.first())
        {
            //dernier test sur le groupe 
            if(testvalidite != 1)
            {
                //modification de l'ID 
                this.Connection.createStatement().executeUpdate("UPDATE seance_groupe SET Id_Groupe = '"+p_IdGroupe+"';");
            }
        }
  }
  
  
  public int findIdGroupe (String p_NomGroupe) throws SQLException
  {
      int p_IdGroupe=0;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM groupe WHERE Nom = '" + p_NomGroupe + "';");
      if(result.first())
        {
            p_IdGroupe = result.getInt("Id_Groupe");
        }
      return p_IdGroupe;
  }
  
  
  public int testgroupevalide (int p_IdGroupe, int p_IdSeance) throws SQLException
  {
      int test=1;
      SeanceDAO seance = new SeanceDAO();
      Date date = seance.find(p_IdSeance).getDate();
      Date date2;
      System.out.println(date);
      Time heuredebut = seance.find(p_IdSeance).getHeure_Debut();
      Time heuredebut2;
      System.out.println(heuredebut);
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_groupe WHERE Id_Groupe = '" + p_IdGroupe + "';");
      if(result.first())
        {
          heuredebut2 = seance.find(result.getInt("Id_Seance")).getHeure_Debut();
          System.out.println(heuredebut2);
          date2 = seance.find(result.getInt("Id_Seance")).getDate();
          System.out.println(date2);
          test=0;
          //salle déjà prise
          if((heuredebut2.equals(heuredebut))&&(date2.equals(date)))
          {
            test = 1;
          }
        }           
      
      return test;
  }
  public JTable ListeGroupe (int p_IdSeance){
          Seance seance = new Seance();
          SeanceDAO seanceDao = new SeanceDAO();
          JTable table = new JTable();
          seance = seanceDao.find(p_IdSeance);
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT groupe.Nom,promotion.Id_Promotion FROM groupe,promotion WHERE promotion.Id_Promotion = groupe.Id_Promotion");
            ResultSetMetaData resultMeta = result.getMetaData();
            //création d'un tableau de type String de "getcolumncount" colonnes
            Object[] columnNames = new String[resultMeta.getColumnCount()];
                    //new String[resultMeta.getColumnCount()];
            for (int i = 1; i <= resultMeta.getColumnCount(); i++)
            {   
                columnNames[i-1]=resultMeta.getColumnName(i);//récupération du nom de chaques colonnes
            }
            //System.out.println(Arrays.toString(columnNames));
            List<Object[]> donnee = new ArrayList<>();
            donnee.add(columnNames);
            while(result.next()) 
            {
             //test si groupe dispo à cette horaire
             //int Id_Groupe = findIdGroupe(result.getString("groupe.Nom"));
             int Id_Groupe = result.getInt("Id_Groupe");
             //int testvalidite = testgroupevalide (Id_Groupe, p_IdSeance);
             //if (testvalidite != 1)
             //{
                // on créé un tableau pour stocker la ligne courante
                Object[] ligne = new Object[resultMeta.getColumnCount()];
                for (int i = 1; i <= resultMeta.getColumnCount(); i++) 
                   {
                       ligne[i-1]=result.getObject(i);
                   }
               donnee.add(ligne); // on ajoute la ligne à la liste
             //}            
            }
         table = new JTable( donnee.stream().toArray(Object[][]::new), columnNames); // on convertit la liste en tableau pour appeler le constructeur et créer une seule JTable
        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    return table;
     }
}
