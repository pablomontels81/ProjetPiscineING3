/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import projet_java.Enseignant;
import projet_java.Cours;
import projet_java.Utilisateur;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class EnseignantDAO extends Dao<Enseignant>{
  
    public EnseignantDAO() 
  {
    super();
  } 
 
    /**
     *
     * @param id_utilisateur
     * @param id_cours
     * @return
     */
  public Enseignant findEnseignant(int id_utilisateur, int id_cours) 
  {
    //Création des variables
    Enseignant enseignant = new Enseignant();
    Utilisateur utilisateur = new Utilisateur();
    UtilisateurDAO utilisateurDao = new UtilisateurDAO();
    Cours cours = new Cours();
    CoursDAO coursDao = new CoursDAO();
    
    //Vérification si les deux id existent
    utilisateur = utilisateurDao.find(id_utilisateur);
    cours = coursDao.find(id_cours);

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM enseignant WHERE Id_Utilisateur = " + id_utilisateur + "AND Id_Cours = " + id_cours + ";");
            if(result.first())
            {
                enseignant = new Enseignant(id_utilisateur,id_cours); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return enseignant;
  }
  
  public JTable listeenseignant ()
  {
      JTable table = new JTable();
      
      return table;
  }
  
  public Enseignant find(int id)
  {
       Enseignant enseignant = new Enseignant();
       try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM enseignant WHERE Id_Utilisateur = " + id + ";");
            if(result.first())
            {
                enseignant = new Enseignant(id, result.getInt("Id_Cours")); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return enseignant;
  }
  
  public void add(Enseignant p_enseignant) throws SQLException
  {
      int p_IdEnseignant = p_enseignant.getId_Enseignant();
      int p_IdCours = p_enseignant.getId_Cours();
      this.Connection.createStatement().executeUpdate("INSERT INTO enseignant (Id_Utilisateur, Id_Cours) VALUES ('"+p_IdEnseignant+"','"+p_IdCours+"');");
  }
}