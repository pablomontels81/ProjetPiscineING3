/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Utilisateur 
{
    protected int id;
    protected String email;
    protected String psswd;  
    protected String nom;
    protected String prenom;
    protected int droit;
    
    //Constructeurs sans paramètres 
    public Utilisateur()
    {
        id = 0;
        email = null;
        psswd = null;  
        nom = null;
        prenom = null;
        droit = 0;
    }
 
    //constructeur avec paramètres 
    public Utilisateur(int p_id, String p_email, String p_psswd, String p_nom, String p_prenom, int p_droit)
    {
        this.id = p_id;
        this.email = p_email;
        this.psswd = p_psswd;
        this.nom = p_nom;
        this.prenom = p_prenom;
        this.droit = p_droit;
    }
   
  /*************** Accesseurs *************/
                
  /*** Geteurs
     * @return  ***/
  public int getId() 
  {
    return id;
  }
  public String getEmail() 
  {
    return email;
  }
  public String getPsswd() 
  {
    return psswd;
  }
  public String getNom() 
  {
    return nom;
  }
  public String getPrenom() 
  {
    return prenom;
  }
   public int getDroit() 
  {
    return droit;
  }
  /*** Setteurs ***/
  public void setId(int id) 
  {
    this.id = id;
  }
  public void setEmail(String email) 
  {
    this.email = email;
  }
  public void setPsswd(String psswd) 
  {
    this.psswd = psswd;
  }

  public void setNom(String nom) 
  {
    this.nom = nom;
  }
  public void setPrenom(String prenom) 
  {
    this.prenom = prenom;
  }  
  public void setDroit(int droit) 
  {
    this.droit = droit;
  }
    
}