/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Salle {
    
    protected int id_salle ;
    protected int id_site ;
    protected String nom ;
    protected int capacite;
    
    //Constructeurs sans paramètres 
    public Salle()
    {
        id_salle = 0;
        id_site = 0;
        capacite = 0;
        nom = null;
        
        
    }
 
    //constructeur avec paramètres 
    public Salle(int p_id1, String p_nom, int p_capacite,  int p_id2)
    {
        id_salle = p_id1;
        id_site = p_id2;
        capacite = p_capacite; 
        nom = p_nom;
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Salle() 
    {
      return id_salle;
    }
    public int getId_Site() 
    {
      return id_site;
    }
    public String getNom() 
    {
      return nom ;
    }
    public int getCapacite() 
    {
      return capacite;
    }
    
    /*** Setteurs
     * @param id ***/
    public void setId_Salle(int id) 
    {
      this.id_salle = id;
    }
    public void setId_Site(int id) 
    {
      this.id_site = id;
    }
    public void setNom(String nom) 
    {
      this.nom = nom;
    }
    public void setEtat(int capacite) 
    {
      this.capacite = capacite;
    } 
    
}