/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author pablo
 */
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import projet_java.Salle;
import projet_java.Seance;
import projet_java.SeanceSalle;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public abstract class SeanceSalleDAO extends Dao<SeanceSalle> {
  
  public SeanceSalleDAO() 
  {
    super();
  } 

    /**
     *
     * @param id_seance
     * @param id_salle
     * @return
     */

  public SeanceSalle find2(int id_seance, int id_salle) 
  {
    SeanceSalle seancesalle = new SeanceSalle();      
    Seance seance = new Seance();
    SeanceDAO seanceDao = new SeanceDAO();
    Salle salle = new Salle();
    SalleDAO salleDao = new SalleDAO();
    
    //Vérification si les deux id existent
    seance = seanceDao.find(id_seance);
    salle = salleDao.find(id_salle);
    
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_salle WHERE Id_Seance = '" + id_seance + "'AND Id_Salle = '" + id_salle + "';");
            if(result.first())
            {
                //seancesalle = new SeanceSalle(seance.getId_Seance(), salle.getId_Salle()); 
                seancesalle = new SeanceSalle(result.getInt("Id_Seance"), result.getInt("Id_Salle"));
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return seancesalle;
  }
  
  public void add(int p_IdSeance,String p_NomSalle) throws SQLException
    {
        int testvalidite;
        int p_IdSalle = findIdSalle (p_NomSalle);
        testvalidite = testsallevalide(p_IdSalle, p_IdSeance);
        if(testvalidite != 1)
        {
            this.Connection.createStatement().executeUpdate("INSERT INTO seance_salle ( Id_Seance, Id_Salle) VALUES ('"+p_IdSeance+"','"+p_IdSalle+"');");
        }
    }
    
 
  public int findIdSalle (String p_NomSalle) throws SQLException
  {
      int p_IdSalle=0;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM salle WHERE Nom = '" + p_NomSalle + "';");
      if(result.first())
        {
            p_IdSalle = result.getInt("Id_Salle");
        }
      return p_IdSalle;
  }
  
  
  public int testsallevalide (int p_IdSalle, int p_IdSeance) throws SQLException
  {
      int test = 0;
      SeanceDAO seance = new SeanceDAO();
      Date date = seance.find(p_IdSeance).getDate();
      Date date2;
      Time heuredebut = seance.find(p_IdSeance).getHeure_Debut();
      Time heuredebut2;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_salle WHERE Id_Salle = '" + p_IdSalle + "';");
      if(result.first())
        {
          heuredebut2 = seance.find(result.getInt("Id_Seance")).getHeure_Debut();
          date2 = seance.find(result.getInt("Id_Seance")).getDate();
          //salle déjà prise
          if((heuredebut2.equals(heuredebut))&&(date2.equals(date)))
          {
            test = 1;
          }
        }            
      
      return test;
  }
  
  public void modifier(String p_NomSalle, int p_IdSeance) throws SQLException
  {
      //récupération de l'ID de la salle 
      int p_IdSalle;
      int testvalidite;
      p_IdSalle = findIdSalle(p_NomSalle);
      testvalidite = testsallevalide(p_IdSalle, p_IdSeance);
      
      //Vérification si le couple existe
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_salle WHERE Id_Seance = '" + p_IdSeance + "'AND Id_Salle = '" + p_IdSalle + "';");
      //Le couple Seance Enseignant existe
      if(result.first())
        {
            //dernier test sur la salle
            if(testvalidite == 1)
            {
                //modification de l'ID 
                this.Connection.createStatement().executeUpdate("UPDATE seance_groupe SET Id_Groupe = '"+p_IdSalle+"';");
            }
        }
  }
  
  public JTable ListeSalle (int p_IdSeance){
          Seance seance = new Seance();
          SeanceDAO seanceDao = new SeanceDAO();
          JTable table = new JTable();
          seance = seanceDao.find(p_IdSeance);
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT  salle.Nom, salle.Capacite  FROM salle;");
            ResultSetMetaData resultMeta = result.getMetaData();
            //création d'un tableau de type String de "getcolumncount" colonnes
            Object[] columnNames = new String[resultMeta.getColumnCount()];
                    //new String[resultMeta.getColumnCount()];
            for (int i = 1; i <= resultMeta.getColumnCount(); i++)
            {   
                columnNames[i-1]=resultMeta.getColumnName(i);//récupération du nom de chaques colonnes
            }
            //System.out.println(Arrays.toString(columnNames));
            List<Object[]> donnee = new ArrayList<>();
            donnee.add(columnNames);
            while(result.next()) 
            {
             //test si enseignant dispo à cette horaire
             int Id_Salle = findIdSalle(result.getString("salle.Nom"));
             int testvalidite = testsallevalide (Id_Salle, p_IdSeance);
             if (testvalidite == 0)
             {
                 // on créé un tableau pour stocker la ligne courante
                Object[] ligne = new Object[resultMeta.getColumnCount()];
                for (int i = 1; i <= resultMeta.getColumnCount(); i++) 
                   {
                       ligne[i-1]=result.getObject(i);
                   }
               donnee.add(ligne); // on ajoute la ligne à la liste
             }            
            }
         table = new JTable( donnee.stream().toArray(Object[][]::new), columnNames); // on convertit la liste en tableau pour appeler le constructeur et créer une seule JTable
        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    return table;
     }
  
}
