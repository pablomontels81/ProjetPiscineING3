/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Cours {
    
    protected int id_cours ;
    protected String nom;
    
    //Constructeurs sans paramètres 
    public Cours()
    {
        id_cours = 0;
        nom = null;
    }
 
    //constructeur avec paramètres 
    public Cours(int p_id, String p_nom)
    {
        id_cours = p_id;
        nom = p_nom;
    }
    
     /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Cours() 
    {
      return id_cours;
    }
    public String getNom() 
    {
      return nom;
    } 
    
    /*** Setteurs
     * @param id ***/
    public void setId_Cours(int id) 
    {
      this.id_cours = id;
    }
    public void setNom(String nom) 
    {
      this.nom = nom;
    }
    
}