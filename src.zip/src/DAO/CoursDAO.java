/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import projet_java.Cours;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class CoursDAO extends Dao<Cours>{
    
  public CoursDAO() 
  {
    super();
  } 
  @Override
  public Cours find(int id) 
  {
    Cours cours = new Cours();      

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM cours WHERE Id_Cours = " + id + ";");
            if(result.first())
            {
                cours = new Cours(id, result.getString("Nom")); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return cours;
  }
  
  public int findIdCours(String Nom_Cours) throws SQLException
  {
      int p_IdCours=0;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM cours WHERE Nom = '" + Nom_Cours + "';");
      if(result.first())
        {
            p_IdCours = result.getInt("Id_Cours");            
        }
      return p_IdCours;
  }
  
  public void add(Cours p_cours) throws SQLException
  {
      String p_nom = p_cours.getNom();
      int p_id = p_cours.getId_Cours();
      this.Connection.createStatement().executeUpdate("INSERT INTO cours (Id_Cours, Nom) VALUES ('"+p_id+"','"+p_nom+"');");
  }
  
  public JComboBox ListeCours () throws SQLException
  {
      JComboBox listecours = new JComboBox();
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT Nom FROM cours;");
      ResultSetMetaData resultMeta = result.getMetaData();
      List<Object[]> donnee = new ArrayList<>();
      while(result.next()) 
        {
            listecours.addItem(result.getString("Nom")); // on ajoute la ligne à la liste                
        }
      return listecours;
      
  }
    
}