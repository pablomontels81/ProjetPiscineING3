/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Promotion;
/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class PromotionDAO extends Dao<Promotion>{
    
  public PromotionDAO() 
  {
    super();
  } 
  @Override
  public Promotion find(int id) 
  {
    Promotion promotion = new Promotion();      

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM promotion WHERE Id_Promotion = " + id + ";");
            if(result.first())
            {
                promotion = new Promotion(id, result.getString("Nom")); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return promotion;
  }
  
  public void add(Promotion p_promotion) throws SQLException
  {
      String p_nom = p_promotion.getNom();
      this.Connection.createStatement().executeUpdate("INSERT INTO promotion (Nom) VALUES ('"+p_nom+"');");
  }
    
}