/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Salle;
import projet_java.Site;
/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class SalleDAO extends Dao<Salle>{
    
  public SalleDAO() 
  {
    super();
  } 
  @Override
  public Salle find(int id) 
  {
    Salle salle = new Salle();      
    Site site = new Site();
    SiteDAO siteDao = new SiteDAO();
    
    //Vérification si les deux id existent
    site = siteDao.find(id);
    
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM salle WHERE Id_Salle = " + id);
            if(result.first())
            {
                salle = new Salle(id , result.getString("Nom"), result.getInt("Capacite"), site.getId_Site());
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return salle;
  }
  public void add(Salle p_salle) throws SQLException
    {
        String p_nom = p_salle.getNom();
        int p_capacite = p_salle.getCapacite();
        int p_IdSite = p_salle.getId_Site();
        this.Connection.createStatement().executeUpdate("INSERT INTO salle ( Nom, Capacite, Id_Site) VALUES ('"+p_nom+"','"+p_capacite+"','"+p_IdSite+"');");
    }
    
}
