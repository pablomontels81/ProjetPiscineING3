/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import static DAO.Connection.con;
import java.sql.Connection;
/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 * @param <T>
 */
public abstract class Dao<T> 
{
    protected Connection Connection = null;

    public Dao()
    {
      this.Connection = con();
    }
        
    public abstract T find(int id);
}