/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Fenetre.MauvaiseConnexion;
import Fenetre.MenuAdmin;
import Fenetre.MenuEnseignant;
import Fenetre.MenuEtudiant;
import Fenetre.MenuPedago;
import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Utilisateur;

/**
 *
 * @author bouchenoiregauthier
 */
public class UtilisateurDAO extends Dao<Utilisateur>
{
  public UtilisateurDAO() 
  {
    super();
  }

    /**
     *
     * @param email
     * @param mdp
     */
    public void ConnexionUtilisateur(String email, String mdp){
        try {
            
                ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM Utilisateur WHERE Email = '" + email + "'AND Passwd = '" + mdp + "';");
                if(result.next()){
                   int choix =  result.getInt("Droit");
                   System.out.println(choix);
                   switch (choix){
                       case 0 :
                           MenuAdmin menu_ad = new MenuAdmin(result.getInt("Id_Utilisateur"));
                           break;
                       case 1 :
                           MenuPedago menu_pedago = new MenuPedago(result.getInt("Id_Utilisateur"));
                           break;
                       case 2:
                           MenuEnseignant menu_ens = new MenuEnseignant(result.getInt("Id_Utilisateur"));
                           break;
                       case 3 :
                           MenuEtudiant menu = new MenuEtudiant(result.getInt("Id_Utilisateur"));
                           break;
                               
                }
                   
                }
                else
                {
                    MauvaiseConnexion mauvais = new MauvaiseConnexion();
                }
        } catch (SQLException e) 
            {
            
            }
  }
@Override
  public Utilisateur find(int id) 
  {
    Utilisateur utilisateur = new Utilisateur();

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM utilisateur WHERE Id_Utilisateur = " + id + ";");
            if(result.first())
            {
               
               utilisateur = new Utilisateur(id, result.getString("Email"),result.getString("Passwd"), result.getString("Nom"), result.getString("Prenom"), result.getInt("Droit"));
        
            }
            else
            {
                System.out.println("kiki");
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
     return utilisateur;
  }
  public void addUtilisateur(Utilisateur p_utilisateur) throws SQLException
    {
        String p_email = p_utilisateur.getEmail();
        String p_passwd = p_utilisateur.getPsswd();
        String p_nom = p_utilisateur.getNom();
        String p_prenom = p_utilisateur.getPrenom();
        int p_droit = p_utilisateur.getDroit();
        this.Connection.createStatement().executeUpdate("INSERT INTO utilisateur (Email, Passwd, Nom, Prenom, Droit) VALUES ('"+p_email+"','"+p_passwd+"','"+p_nom+"','"+p_prenom+"','"+p_droit+"');");
    }
  
 
}