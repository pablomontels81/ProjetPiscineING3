/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class MenuPedago extends JFrame implements ActionListener{
    
    private  JButton ok,ok1,ok2;
    private  JPanel p1, p2, p3;
    
    public MenuPedago(int id_utilisateur){
      super("Menu Pedagogie");
        
        setLayout(new BorderLayout());
        setBounds(0, 0, 500, 150);
        setResizable(true);
        setVisible(true);
        
        ok = new JButton("Afficher mon planning");
        ok1 = new JButton("Rechercher Scéance");
        ok2 = new JButton("Déconnexion");
        
        
        ok2.setForeground(Color.RED);
        // creation des panneaux
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        
         // mise en page des panneaux
        p1.setLayout(new FlowLayout());
        p2.setLayout(new FlowLayout(1,50,35));
        
        
        //construction de la fenêtre
        p1.add("Right", ok2);
        p2.add(ok);
        p2.add(ok1);
        
        //création des actions listeners
        ok.addActionListener(this);
        ok1.addActionListener(this);
        ok2.addActionListener(this);
        
        //mise en place des panels
        add("South", p1);
        add("Center", p2);
        
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent evet) {
       Object source = evet.getSource();
         if (source == ok2) {
             setVisible(false);
             PageConnexion con = new PageConnexion();
    }
         if (source == ok1) {
             setVisible(false);
             RechercheSeance seance = new RechercheSeance();
    } 
}
}
    

