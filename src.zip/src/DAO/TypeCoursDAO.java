/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import projet_java.TypeCours;

/**
 *
 * @author pablo
 */
public class TypeCoursDAO extends Dao<TypeCours> {
  
  public TypeCoursDAO() 
  {
    super();
  } 
  @Override
  public TypeCours find(int id) 
  {
    TypeCours typecours = new TypeCours();      

    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM typecours WHERE Id_Type = " + id);
            if(result.first())
            {
                typecours = new TypeCours(id,result.getString("Nom"));  
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return typecours;
  }
  
  public int findIdTypeCours(String Nom_TypeCours) throws SQLException
  {
      int p_IdCours=0;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM typecours WHERE Nom = '" + Nom_TypeCours + "';");
      if(result.first())
        {
            p_IdCours = result.getInt("Id_Type");            
        }
      return p_IdCours;
  }
  
  public void add(TypeCours p_typecours) throws SQLException
    {
        String p_nom = p_typecours.getNom();
        this.Connection.createStatement().executeUpdate("INSERT INTO typecours ( Nom) VALUES ('"+p_nom+"');");
    }
  
   public JComboBox ListeTypeCours () throws SQLException
  {
      JComboBox listecours = new JComboBox();
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT Nom FROM typecours;");
      ResultSetMetaData resultMeta = result.getMetaData();
      List<Object[]> donnee = new ArrayList<>();
      while(result.next()) 
        {
            listecours.addItem(result.getString("Nom"));
        }
      return listecours;
      
  }
}