/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import projet_java.Enseignant;
import projet_java.Seance;
import projet_java.SeanceEnseignant;
/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public abstract class SeanceEnseignantDAO extends Dao<SeanceEnseignant> {
  
  public SeanceEnseignantDAO() 
  {
    super();
  } 
  public SeanceEnseignant findEnseignant(int id_seance, int id_enseignant) 
  {
    SeanceEnseignant seanceenseignant = new SeanceEnseignant();
    Seance seance = new Seance();
    SeanceDAO seanceDao = new SeanceDAO();
    Enseignant enseignant = new Enseignant();
    EnseignantDAO enseignantDao = new EnseignantDAO();
    
    //Vérification si les deux id existent
    seance = seanceDao.find(id_seance);
    enseignant = enseignantDao.find(id_enseignant);
    
    try {
                ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_enseignant WHERE Id_Seance = '" + id_seance + "'AND Id_Enseignant = '" + id_enseignant + "';");
                if(result.first())
                {
                    enseignant = new Enseignant(seance.getId_Seance(),enseignant.getId_Enseignant()); 
                }

            } catch (SQLException e) 
                {
                    e.printStackTrace();
                }
    
    return seanceenseignant;
  }
  
  public void add(int p_IdSeance, String p_NomEnseignant) throws SQLException
    {
        int testvalidite;
        int testvaliditecours;
        int p_IdEnseignant;
        p_IdEnseignant = findIdEnseignant(p_NomEnseignant);
        testvaliditecours = testenseignantcoursvalide(p_IdEnseignant, p_IdSeance);
        testvalidite = testenseignantvalide(p_IdEnseignant, p_IdSeance);
        if((testvalidite != 1)&&(testvaliditecours ==1))
        {
            this.Connection.createStatement().executeUpdate("INSERT INTO seance_enseignant ( Id_Seance, Id_Enseignant) VALUES ('"+p_IdSeance+"','"+p_IdEnseignant+"');");
        }
    }
  public void modifier(String p_NomEnseignant, int p_IdSeance) throws SQLException
  {
      //récupération de l'ID de la salle 
      int p_IdEnseignant;
      int testvalidite;
      int testvaliditecours;
      p_IdEnseignant = findIdEnseignant(p_NomEnseignant);
      testvalidite = testenseignantvalide(p_IdEnseignant, p_IdSeance);
      testvaliditecours = testenseignantcoursvalide(p_IdEnseignant, p_IdSeance);
      //Vérification si le couple existe
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_enseignant WHERE Id_Seance = '" + p_IdSeance + "'AND Id_Enseignant = '" + p_IdEnseignant + "';");
      //Le couple Seance Enseignant existe
      if(result.first())
        {
            //dernier test sur la salle
            if((testvalidite != 1)&&(testvaliditecours ==1))
            {
                //modification de l'ID 
                this.Connection.createStatement().executeUpdate("UPDATE seance_enseignant SET Id_Enseignant = '"+p_IdEnseignant+"';");
            }
        }
  }
  
  
  public int findIdEnseignant (String p_NomEnseignant) throws SQLException
  {
      int p_IdEnseignant=0;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM utilisateur WHERE Nom = '" + p_NomEnseignant + "';");
      if(result.first())
        {
            ResultSet result2 = this.Connection.createStatement().executeQuery("SELECT * FROM enseignant WHERE Id_Utilisateur = '" + result.getInt("Id_Utilisateur") + "';");
            if(result2.first())
            {
            p_IdEnseignant = result2.getInt("Id_Utilisateur");
            }
        }
      return p_IdEnseignant;
  }
  
  public int testenseignantcoursvalide (int p_IdEnseignant, int p_IdSeance) throws SQLException
  {
      int test = 0;
      SeanceDAO seance = new SeanceDAO();
      EnseignantDAO enseignant = new EnseignantDAO();
      int Id_Cours = seance.find(p_IdSeance).getId_Cours();
      
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM enseignant WHERE Id_Utilisateur = '" + p_IdEnseignant + "' AND Id_Cours = '"+ Id_Cours +"';");
      if(result.first())
      {
          test = 1;
      }

      return test;
  }
  public int testenseignantvalide (int p_IdEnseignant, int p_IdSeance) throws SQLException
  {
      int test = 0;
      SeanceDAO seance = new SeanceDAO();
      Date date = seance.find(p_IdSeance).getDate();
      Date date2;
      Time heuredebut = seance.find(p_IdSeance).getHeure_Debut();
      Time heuredebut2;
      ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM seance_enseignant WHERE Id_Enseignant = '" + p_IdEnseignant + "';");
      if(result.first())
        {
          heuredebut2 = seance.find(result.getInt("Id_Seance")).getHeure_Debut();
          date2 = seance.find(result.getInt("Id_Seance")).getDate();
          //salle déjà prise
          if((heuredebut2.equals(heuredebut))&&(date2.equals(date)))
          {
            test = 1;
          }
        }            
      
      return test;
  }
  public JTable ListeEnseignant (int p_IdSeance){
          Seance seance = new Seance();
          SeanceDAO seanceDao = new SeanceDAO();
          JTable table = new JTable();
          seance = seanceDao.find(p_IdSeance);
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT utilisateur.Nom FROM enseignant, utilisateur, cours WHERE enseignant.Id_Utilisateur = utilisateur.Id_Utilisateur AND enseignant.Id_Cours = cours.Id_Cours AND cours.ID_COurs = '" + seance.getId_Cours() +"';");
            ResultSetMetaData resultMeta = result.getMetaData();
            //création d'un tableau de type String de "getcolumncount" colonnes
            Object[] columnNames = new String[resultMeta.getColumnCount()];
                    //new String[resultMeta.getColumnCount()];
            for (int i = 1; i <= resultMeta.getColumnCount(); i++)
            {   
                columnNames[i-1]=resultMeta.getColumnName(i);//récupération du nom de chaques colonnes
            }
            //System.out.println(Arrays.toString(columnNames));
            List<Object[]> donnee = new ArrayList<>();
            donnee.add(columnNames);
            while(result.next()) 
            {
             //test si enseignant dispo à cette horaire
             int Id_Enseignant = findIdEnseignant(result.getString("utilisateur.Nom"));
             int testvalidite = testenseignantvalide (Id_Enseignant, p_IdSeance);
             if (testvalidite == 0)
             {
                 // on créé un tableau pour stocker la ligne courante
                Object[] ligne = new Object[resultMeta.getColumnCount()];
                for (int i = 1; i <= resultMeta.getColumnCount(); i++) 
                   {
                       ligne[i-1]=result.getObject(i);
                   }
               donnee.add(ligne); // on ajoute la ligne à la liste
             }            
            }
         table = new JTable( donnee.stream().toArray(Object[][]::new), columnNames); // on convertit la liste en tableau pour appeler le constructeur et créer une seule JTable
        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    return table;
     }
}

