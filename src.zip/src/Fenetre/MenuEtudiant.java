/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import DAO.UtilisateurDAO;
import javax.swing.JLabel;
import projet_java.Utilisateur;


/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class MenuEtudiant extends JFrame implements ActionListener  {
    
    private final JButton ok,ok1,ok2;
    private final JPanel p1, p2, p3;
    private final JLabel l1;
    
    public MenuEtudiant(int id_utilisateur){
        super("Menu");
        setLayout(new BorderLayout());
        setBounds(0, 0, 500, 150);
        setResizable(true);
        setVisible(true);
        
        //Récupération Nom & Prénom de l'utilisateur
        UtilisateurDAO utilisateurDao;
        utilisateurDao = new UtilisateurDAO();
        Utilisateur utilisateur;
        utilisateur = utilisateurDao.find(id_utilisateur);
        
        ok = new JButton("Afficher mon planning");
        ok1 = new JButton("Afficher liste de cours");
        ok2 = new JButton("Déconnexion");
        l1 = new JLabel("Bonjour "+utilisateur.getPrenom()+" "+utilisateur.getNom()+" ");
        
        ok2.setForeground(Color.RED);
        
        // creation des panneaux
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        
         // mise en page des panneaux
        p1.setLayout(new FlowLayout());
        p2.setLayout(new FlowLayout(1,50,35));
        p3.setLayout(new FlowLayout());
                
        
        //construction de la fenêtre
        p1.add("Right", ok2);
        p2.add(ok);
        p2.add(ok1);
        p3.add(l1);
        
        //création des actions listeners
        ok.addActionListener(this);
        ok1.addActionListener(this);
        ok2.addActionListener(this);
        
        //mise en place des panels
        add("South", p1);
        add("Center", p2);
        add("North", p3);
        
        
        
        
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent evet) {
       Object source = evet.getSource();
         if (source == ok2) {
             setVisible(false);
             PageConnexion con = new PageConnexion();
    }
    } 
}
