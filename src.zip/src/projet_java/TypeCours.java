/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class TypeCours {
    
    protected int id_type ;
    protected String nom ;
    
    //Constructeurs sans paramètres 
    public TypeCours()
    {
        id_type = 0;
        nom = null;
        
        
    }
 
    //constructeur avec paramètres 
    public TypeCours(int p_id1, String p_nom)
    {
        id_type = p_id1;
        nom = p_nom;
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Type() 
    {
      return id_type;
    }
    public String getNom() 
    {
      return nom ;
    }
    
    /*** Setteurs
     * @param id ***/
    public void setId_Type(int id) 
    {
      this.id_type = id;
    }
    public void setNom(String nom) 
    {
      this.nom = nom;
    } 
}