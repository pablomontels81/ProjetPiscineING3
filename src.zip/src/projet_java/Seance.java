/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

import java.sql.Time;
import java.sql.Date;


/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Seance {
    protected int id_seance ;
    protected int semaine;
    protected Date date;
    protected Time heure_debut;
    protected Time heure_fin;
    protected int etat;
    protected int id_cours;
    protected int id_type;
    
    
    
    //Constructeurs sans paramètres 
    public Seance()
    {
        id_seance = 0;
        id_cours = 0;
        id_type = 0;
        etat = 0;
        semaine = 0;
        heure_debut = null;
        heure_fin = null;
        date = null;
        
    }
 
    //constructeur avec paramètres 
    public Seance(int p_id1, int p_semaine, Date p_date, Time p_heuredebut, Time p_heurefin, int p_etat, int p_id2, int p_id3)
    {
        id_seance = p_id1;
        id_cours = p_id2;
        id_type = p_id3;
        etat = p_etat;
        semaine = p_semaine;
        heure_debut = p_heuredebut;
        heure_fin = p_heurefin;
        date = p_date; 
        
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getId_Seance() 
    {
      return id_seance;
    }
    public int getId_Cours() 
    {
      return id_cours;
    }
    public int getId_Type() 
    {
      return id_type;
    }
    public int getEtat() 
    {
      return etat;
    }
    public int getSemaine() 
    {
      return semaine;
    }
    public Time getHeure_Debut() 
    {
      return heure_debut;
    }
    public Time getHeure_Fin() 
    {
      return heure_fin;
    }
    public Date getDate() 
    {
      return date;
    }
    
    /*** Setteurs
     * @param id ***/
    public void setId_Seance(int id) 
    {
      this.id_seance = id;
    }
    public void setId_Cours(int id) 
    {
      this.id_cours = id;
    }
    public void setId_Type(int id) 
    {
      this.id_type = id;
    }
    public void setEtat(int etat) 
    {
      this.etat = etat;
    } 
    public void setSemaine(int semaine) 
    {
      this.semaine = semaine;
    }
    public void setHeure_Debut(Time heure_debut) 
    {
      this.heure_debut = heure_debut;
    }
    public void setHeure_Fin(Time heure_fin) 
    {
      this.heure_fin = heure_fin;
    }
    public void setDate(Date date) 
    {
      this.date = date;
    }
}
