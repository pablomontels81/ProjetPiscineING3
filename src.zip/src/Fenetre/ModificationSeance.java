/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import DAO.CoursDAO;
import DAO.SeanceDAO;
import DAO.TypeCoursDAO;
import projet_java.Seance;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import projet_java.Cours;
import projet_java.TypeCours;

/**
 *
 * @author pablo
 */
public class ModificationSeance extends JFrame implements ActionListener{
    private final JButton AjoutEnseignant,AjoutGroupe,AjoutSalle, ModifEnseignant, ModifGroupe, ModifSalle;
    private final JLabel id_seance;
    private final JPanel p1,p2,p3;
    private final JTextArea id;
    
    public ModificationSeance(int seance_id){
    
        super("Choix de modification de Seance");
        
        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 650, 400);
        setResizable(true);
        setVisible(true);
        
        //creation des bouttons
        AjoutEnseignant = new JButton("Ajouter un Enseignant à cette Séance");
        AjoutGroupe = new JButton("Ajouter un Groupe à cette Séance");
        AjoutSalle = new JButton("Ajouter une Salle à cette Séance");
        
        ModifEnseignant = new JButton("Modifier l'Enseignant de cette Séance");
        ModifGroupe = new JButton("Modifier le Groupe de cette Séance");
        ModifSalle = new JButton("Modifier la Salle de cette Séance");
        
        ///récupération info sur séance
        //variable 
        SeanceDAO SeanceDao;
        SeanceDao = new SeanceDAO();
        Seance Seance;
        CoursDAO CoursDao;
        CoursDao = new CoursDAO();
        Cours Cours;
        TypeCoursDAO TypeCoursDao;
        TypeCoursDao = new TypeCoursDAO();
        TypeCours TypeCours;
        
        //récupération Date et Heure de Début
        Seance = SeanceDao.find(seance_id);
        
        //récupération des Nom de Type de Cours et de Cours
        Cours = CoursDao.find(Seance.getId_Cours());
        TypeCours = TypeCoursDao.find(Seance.getId_Type());
        
        // creation des labels
        id_seance = new JLabel("Séance de "+TypeCours.getNom()+" de "+Cours.getNom()+" le "+Seance.getDate()+" à :"+Seance.getHeure_Debut()+" ", JLabel.CENTER);
        
        id = new JTextArea(""+seance_id);
        // creation des panneaux
        p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        

        p1.add(id_seance);
        p2.add(AjoutEnseignant);
        p2.add(AjoutGroupe);
        p2.add(AjoutSalle);
        p2.add(ModifEnseignant);
        p2.add(ModifGroupe);
        p2.add(ModifSalle); 
        p3.add(id);
        p3.setVisible(false);
        
        AjoutEnseignant.addActionListener(this);
        AjoutGroupe.addActionListener(this);
        AjoutSalle.addActionListener(this);
        ModifEnseignant.addActionListener(this);
        ModifGroupe.addActionListener(this);
        ModifSalle.addActionListener(this);
        
        //mise en place des panels
        add("North", p1);
        add("Center", p2);
        add("South", p3);
        
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent evet) {
        Object source = evet.getSource();
        if (source == AjoutEnseignant)
        {
            //Fenetre Ajout dans table Seance_Enseignant
            AjoutEnseignant ajout = new AjoutEnseignant(Integer.parseInt(id.getText()));
           setVisible(false);
        }
        else if (source == AjoutGroupe)
        {
            //Fenetre Ajout dans table Seance_Groupe
            AjoutGroupe ajout = new AjoutGroupe(Integer.parseInt(id.getText()));
           setVisible(false);
           
        }
        else if (source == AjoutSalle)
        {
            //Fenetre Ajout dans table Seance_Salle 
             AjoutSalle ajout = new AjoutSalle(Integer.parseInt(id.getText()));
            setVisible(false);
        }
        else if (source == ModifEnseignant)   
        {
            //Fenetre Modif dans table Seance_Enseignant  
            System.out.println("Fenetre Modif dans table Seance_Enseignant");
            setVisible(false);
        }
        else if (source == ModifGroupe)
        {
            //Fenetre Modif dans table Seance_Groupe  
            System.out.println("Fenetre Modif dans table Seance_Groupe");
            setVisible(false);
        }
        else if (source == ModifSalle)
        {
            //Fenetre Modif dans table Seance_Salle 
            System.out.println("Fenetre Modif dans table Seance_Salle ");
            setVisible(false);
        }
    }    
}
