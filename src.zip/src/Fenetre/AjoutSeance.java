/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;
import DAO.CoursDAO;
import DAO.SeanceDAO;
import DAO.TypeCoursDAO;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */


public class AjoutSeance extends JFrame implements ActionListener {
    private final JButton ajoutseance;
    private final JLabel titre,date,heure, cours, type_de_cours;
    private final JPanel p1,pdate,pheure,pcours,ptypecours, center, pbutton;
    private final JComboBox choixhoraire, choixcours, choixtypecours;
    private final JTextField choixdate;
    
    public AjoutSeance() throws SQLException{
        
      
      super("Ajout d'une Seance");
      
      CoursDAO coursdao = new CoursDAO();
      TypeCoursDAO typecoursdao = new TypeCoursDAO();
      // mise en page (layout) de la fenetre visible
      setLayout(new BorderLayout());
      setBounds(0, 0, 500, 400);
      setResizable(true);
      setVisible(true);
      // creation des panneaux
      p1 = new JPanel();
      pdate = new JPanel();
      pheure = new JPanel();
      pcours = new JPanel();
      ptypecours = new JPanel();
      center = new JPanel();
      pbutton = new JPanel();
      
      //creation du boutton
      ajoutseance = new JButton("Ajouter une séance");
      ajoutseance.addActionListener(this);
      
      //création Combobox 
      Object[] elements = new Object[]{"8h30 - 10h00", "10h15 - 11h45", "12h00 - 13h30", "13h45 - 15h15", "15h30 - 17h00", "17h15 - 18h45", "19h00 - 20h30"};
      choixhoraire = new JComboBox(elements);
      choixcours = coursdao.ListeCours();
      choixtypecours = typecoursdao.ListeTypeCours();
      
      //création JLabel
      titre = new JLabel("Veuillez saisir les paramètres de la séance à ajouter");
      date = new JLabel("Saisissez la Date :");
      heure = new JLabel("Sélectionnez le créneau Horaire :");
      cours = new JLabel("Sélectionnez le cours :");
      type_de_cours = new JLabel("Sélectionnez le type de cours :");
      
      //création JTextField 
      choixdate = new JTextField();
      choixdate.setPreferredSize(new Dimension(150,30));
       
              
      p1.add(titre);
      
      pdate.add(date);
      pdate.add(choixdate);
      
      pheure.add(heure);
      pheure.add(choixhoraire);
      
      pcours.add(cours);
      pcours.add(choixcours);
      
      ptypecours.add(type_de_cours);
      ptypecours.add(choixtypecours);
      
      center.add(pdate);
      center.add(pheure);
      center.add(pcours);
      center.add(ptypecours);
      
      pbutton.add(ajoutseance);
              
              
      add("North", p1);
      add("Center", center);
      add("South", pbutton);
      
      addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent evt) {
            System.exit(0); // tout fermer												System.exit(0); // tout fermer
        }
        });
    }
    @Override
    public void actionPerformed(ActionEvent evet) {
        
        
        Object source = evet.getSource();
        CoursDAO coursdao = new CoursDAO();
        TypeCoursDAO typecours = new TypeCoursDAO();
        SeanceDAO seance = new SeanceDAO();
         if (source == ajoutseance) {
           //Création variables de transit
           int semaine;
           Date datecours;
           Time heure_debut;
           Time heure_fin;
           int etat=0;
           int id_cours;
           int id_type;
           
           int testdatecorrect = seance.testdate(choixdate.getText());
           
           
           heure_debut = Time.valueOf("00:00:00");
           heure_fin = Time.valueOf("00:00:00");
           
           if (testdatecorrect == 1)
           {
           //Récupération des infos
            try {
                //Appel à la fonction de recherche de l'Id grâce au nom du Cours 
                id_cours = coursdao.findIdCours(choixcours.getSelectedItem().toString());
                //Appel à la fonction de recherche de l'Id grâce au nom du Type de Cours 
                id_type = typecours.findIdTypeCours(choixtypecours.getSelectedItem().toString());
                datecours = Date.valueOf(choixdate.getText());
                //Appel au Calendrier afin de définir le numéro de la semaine en fonction de la date
                Calendar calDe = Calendar.getInstance(Locale.FRENCH);
                calDe.setTime(datecours);
                semaine = calDe.get(Calendar.WEEK_OF_YEAR);
                //Boucle pour définir les horaires de la séance 
                if (choixhoraire.getSelectedItem().equals("8h30 - 10h00"))
                {
                    heure_debut = Time.valueOf("8:30:00");
                    heure_fin = Time.valueOf("10:00:00");
                }
                else if (choixhoraire.getSelectedItem().equals("10h15 - 11h45"))
                {
                    heure_debut = Time.valueOf("10:15:00");
                    heure_fin = Time.valueOf("11:45:00");
                }
                else if (choixhoraire.getSelectedItem().equals("12h00 - 13h30"))
                {
                    heure_debut = Time.valueOf("12:00:00");
                    heure_fin = Time.valueOf("13:30:00");
                }
                else if (choixhoraire.getSelectedItem().equals("13h45 - 15h15"))
                {
                    heure_debut = Time.valueOf("13:45:00");
                    heure_fin = Time.valueOf("15:15:00");
                }
                else if (choixhoraire.getSelectedItem().equals("15h30 - 17h00"))
                {
                    heure_debut = Time.valueOf("15:30:00");
                    heure_fin = Time.valueOf("17:00:00");
                }
                else if (choixhoraire.getSelectedItem().equals("17h15 - 18h45"))
                {
                    heure_debut = Time.valueOf("17:15:00");
                    heure_fin = Time.valueOf("18:45:00");
                }
                else if (choixhoraire.getSelectedItem().equals("19h00 - 20h30"))
                {
                    heure_debut = Time.valueOf("19:00:00");
                    heure_fin = Time.valueOf("20:30:00");
                }
                System.out.println("Id_Cours: "+id_cours);
                System.out.println("Id_TypeCours: "+id_type);
                System.out.println("HeureDebut: "+heure_debut);
                System.out.println("HeureFin: "+heure_fin);
                //seance.add(semaine, datecours, heure_debut, heure_fin, etat, id_cours, id_type);
            } catch (SQLException ex) {
                System.out.println("Problème récupération ID Cours et TypeCours");
            }
           }
           else 
           {
               setVisible(false);
               MauvaiseAjoutSeance add = new MauvaiseAjoutSeance();
           }
            
           
           
            
         }
//            date = calendrier.getDate().toString();
//            System.out.println(date); 
//          date1 = Date.valueOf(date);
//          System.out.println(date1); 
//        Calendar calDe = Calendar.getInstance(Locale.FRENCH);       
//        calDe.setTime(Date.valueOf(date));
//        int semaine = calDe.get( Calendar.WEEK_OF_YEAR );
        
    }
}
