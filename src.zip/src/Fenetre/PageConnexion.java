/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAO.UtilisateurDAO;



/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class PageConnexion extends JFrame implements ActionListener {
    
    private final JButton con;
    private final JTextField email;
    private final JPasswordField pswd;
    private final JLabel connexion, con_email, con_pswd;
    private final JPanel p1, p2, p3, p4, center;

    public PageConnexion(){
        // creation par heritage de la fenetre
        super("Connexion");

        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 400, 400);
        setResizable(true);
        setVisible(true);

        //creation des bouttons
        con = new JButton("Connexion PlanningByECE");

        //creation zone de texte
        email = new JTextField();
        email.setPreferredSize(new Dimension(150,30));
        pswd = new JPasswordField();
        pswd.setPreferredSize(new Dimension(150,30));
        
        // creation des labels
        connexion = new JLabel("Entrez vos identifiants", JLabel.CENTER);
        con_email = new JLabel("Email : ", JLabel.CENTER);
        con_pswd = new JLabel("Password: ", JLabel.CENTER);
        
        // creation des panneaux
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        center = new JPanel();
        // mise en page des panneaux
        p1.setLayout(new GridLayout(1, 1));
        p2.setLayout(new FlowLayout());
        p3.setLayout(new FlowLayout());
        p4.setLayout(new GridLayout(1, 1));
        center.setLayout(new FlowLayout(1,800,35));

        //construction de la fenêtre
        p1.add(connexion);
        p2.add(con_email);
        p2.add(email);
        p3.add(con_pswd);
        p3.add(pswd);
        p4.add(con);
        center.add(p2);
        center.add(p3);
        center.add(p4);
           
        con.addActionListener(this);
        
        
        //mise en place des panels
        add("North", p1);
        add("Center", center);
       
        
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });

    } 
    
    @Override
    public void actionPerformed(ActionEvent evet) {
         Object source = evet.getSource();
         if (source == con) {
             UtilisateurDAO utilisateurdao= new UtilisateurDAO();
             utilisateurdao.ConnexionUtilisateur(email.getText(), pswd.getText());
             setVisible(false);
             
         }
         
       
    }   
}
