/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import DAO.CoursDAO;
import DAO.SeanceDAO;
import DAO.SeanceGroupeDAO;
import DAO.SeanceSalleDAO;
import DAO.TypeCoursDAO;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import projet_java.Cours;
import projet_java.Seance;
import projet_java.SeanceGroupe;
import projet_java.SeanceSalle;
import projet_java.TypeCours;

/**
 *
 * @author engue
 */
public class AjoutSalle extends JFrame implements ActionListener{
    private final JButton ajoutsalle;
    private final JLabel id_seance, salle;
    private final JPanel p1,p2,p3,p4,p5, center, south;
    private final JTextField nom;
    private final JTable table;
    private final JTextArea id;
    
    public AjoutSalle(int seance_id){
    
        super("Ajout d'une salle a une Seance");
        
        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 500, 400);
        setResizable(true);
        setVisible(true);
        
       
               
        ///récupération info sur séance
        //variable 
        SeanceDAO SeanceDao;
        SeanceDao = new SeanceDAO();
        Seance Seance;
        CoursDAO CoursDao;
        CoursDao = new CoursDAO();
        Cours Cours;
        TypeCoursDAO TypeCoursDao;
        TypeCoursDao = new TypeCoursDAO();
        TypeCours TypeCours;
        SeanceSalleDAO seancesalle;
        seancesalle = new SeanceSalleDAO() {
            @Override
            public SeanceSalle find(int id) {
                return null;
            }
        };
        
        //récupération Date et Heure de Début
        Seance = SeanceDao.find(seance_id);
        
        //récupération des Nom de Type de Cours et de Cours
        Cours = CoursDao.find(Seance.getId_Cours());
        TypeCours = TypeCoursDao.find(Seance.getId_Type());
        id = new JTextArea(""+seance_id);
         //creation des bouttons
        ajoutsalle = new JButton("Ajouter une salle à cette Séance");
        
         //creation zone de texte
        nom = new JTextField();
        nom.setPreferredSize(new Dimension(150,30));
        
        // creation des labels
        id_seance = new JLabel("Séance de "+TypeCours.getNom()+" de "+Cours.getNom()+" le "+Seance.getDate()+" à : "+Seance.getHeure_Debut()+" ", JLabel.CENTER);
        salle = new JLabel("Saisissez le nom de la salle : ");
        // creation des panneaux
        p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p2 = new JPanel();
        p2.setLayout(new FlowLayout(1,50,35));
        p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        p4 = new JPanel();
        p4.setLayout(new FlowLayout());
        p5 = new JPanel();
        p5.setLayout(new FlowLayout());
        p5.setVisible(false);
        center = new JPanel();
        center.setLayout(new FlowLayout());
        south = new JPanel();
        south.setLayout(new FlowLayout());
         
        //p5.setVisible(false);
        
        table= seancesalle.ListeSalle(seance_id);
        
        p1.add(id_seance);
        p2.add(salle); 
        p2.add(nom);
        p3.add(table);
        p4.add(ajoutsalle);
       p5.add(id);
       center.add(p2);
       center.add(p3);
       south.add(p4);
       south.add(p5);
        
        
        ajoutsalle.addActionListener(this);
       
        
        //mise en place des panels
        add("North", p1);
        add("Center", center);
        add("South", south);
        
        
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent evet) {
        Object source = evet.getSource();
        SeanceSalleDAO seancesalle;
        seancesalle = new SeanceSalleDAO() {
            @Override
            public SeanceSalle find(int id) {
                return null;
            }
        };
            
                       
           
        if (source == ajoutsalle) {
            try {
                int testvalidite = seancesalle.testsallevalide(seancesalle.findIdSalle(nom.getText()),Integer.parseInt(id.getText()));
                //Validité OKAY 
                if((testvalidite !=1))
                {
                    
                    try {
                        seancesalle.add(Integer.parseInt(id.getText()),nom.getText());
                        setVisible(false);
                        MenuAdmin menu_ad = new MenuAdmin(1);
                    } catch (SQLException ex) {
                        Logger.getLogger(AjoutGroupe.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                //Mauvaise entrée
                else
                {
                    MauvaiseAjoutSalle next= new MauvaiseAjoutSalle(Integer.parseInt(id.getText()));
                    setVisible(false);
                }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(AjoutGroupe.class.getName()).log(Level.SEVERE, null, ex);
            }
         }

           
    }
}

