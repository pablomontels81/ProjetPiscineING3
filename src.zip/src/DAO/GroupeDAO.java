/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import projet_java.Groupe;
import projet_java.Promotion;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class GroupeDAO extends Dao<Groupe>{
    
  public GroupeDAO() 
  {
    super();
  } 
  @Override
  public Groupe find(int id) 
  {
    Promotion promotion = new Promotion();
    PromotionDAO promotionDao;
    promotionDao = new PromotionDAO();
    Groupe groupe = new Groupe();      

    //Vérification si les deux id existent
    promotion = promotionDao.find(id);
    
    try {
            ResultSet result = this.Connection.createStatement().executeQuery("SELECT * FROM groupe WHERE Id_Groupe = " + id + ";");
            if(result.first())
            {
                groupe = new Groupe(id, result.getString("Nom"), promotion.getId_Promotion()); 
            }

        } catch (SQLException e) 
            {
                e.printStackTrace();
            }
    
    return groupe;
  }
  
  public void add(Groupe p_groupe) throws SQLException
    {
        int p_IdPromotion = p_groupe.getId_Promotion();
        String p_nom = p_groupe.getNom();
        this.Connection.createStatement().executeUpdate("INSERT INTO groupe ( Id_Promotion, Nom) VALUES ('"+p_IdPromotion+"','"+p_nom+"');");
    }
  
  
}