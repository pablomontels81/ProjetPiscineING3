/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.DriverManager;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Connection 
{
    public static com.mysql.jdbc.Connection con() 
    {
        com.mysql.jdbc.Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/projetjava?autoReconnect=true&useSSL=false", "root", "root");
            //System.out.println("psj");
        } catch (Exception e ) {
           System.out.println(e);
        }
        return con;
    }
    
}
