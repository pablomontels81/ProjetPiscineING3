/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class MauvaiseConnexion extends JFrame implements ActionListener  {
    
    private final JButton ok;
    private final JPanel p1, p2;
    private final JLabel erreur;
    
    public MauvaiseConnexion(){
    
        super("Erreur de connexion");
        
        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 300, 150);
        setResizable(true);
        setVisible(true);
        
        //creation des bouttons
        ok = new JButton("Continuer");
        
        // creation des labels
        erreur = new JLabel("Mauvais Identifiants", JLabel.CENTER);
        
        // creation des panneaux
        p1 = new JPanel();
        p1.setLayout(new GridLayout(1, 1));
        p2 = new JPanel();
        p2.setLayout(new GridLayout(1, 1));
        
        p1.add(erreur);
        p2.add(ok);
        
        ok.addActionListener(this);
        
        //mise en place des panels
        add("North", p1);
        add("South", p2);
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
}

    @Override
    public void actionPerformed(ActionEvent evet) {
        Object source = evet.getSource();
         if (source == ok) {
             setVisible(false);
             PageConnexion con = new PageConnexion();
         }
    }

    
}
