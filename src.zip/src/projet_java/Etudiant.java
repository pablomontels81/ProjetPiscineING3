/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class Etudiant extends Utilisateur 
{
    private int numero;
    private int id_groupe;
    //Sans paramètres 
    public Etudiant()
    {
        super();
        numero = 0;
        id_groupe = 0;
    }
    
    //Avec paramètres
    public Etudiant(int p_id, String p_email, String p_psswd, String p_nom, String p_prenom, int p_droit, int p_numero, int p_idgroupe)
    {
        super(p_id, p_email, p_psswd, p_nom, p_prenom, p_droit);
        this.numero = p_numero;
        this.id_groupe = p_idgroupe;
    }
    
    /*************** Accesseurs *************/
                
    /*** Geteurs
     * @return  ***/
    public int getNumero()
    {
        return numero; 
    }
    public int getIdGroupe()
    {
        return id_groupe;
    }
    /*** Setteurs
     * @param id ***/
    public void setNumero(int numero) 
    {
        this.numero = numero;
    }
    public void setIdGroupe(int id_groupe)
    {
        this.id_groupe = id_groupe;
    }
}