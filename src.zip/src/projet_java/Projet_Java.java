/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_java;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import static DAO.Connection.con;
import DAO.Dao;
import DAO.SeanceDAO;
import DAO.SeanceEnseignantDAO;
import DAO.UtilisateurDAO;
import Fenetre.AjoutSeance;
import Fenetre.MauvaiseConnexion;
import Fenetre.MenuEtudiant;

import Fenetre.PageConnexion;
import Fenetre.RechercheSeance;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import projet_java.Utilisateur;

/*
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 * 
 */
public class Projet_Java {

    /**
     * @param args the command line arguments
     */
    

    public static void main(String[] args) throws SQLException, ParseException {
        //Testons des utilisateurs
        
       /*Seance seance1 = new Seance();
        seance1.setId_Seance(1);
        seance1.setId_Cours(1);
        seance1.setId_Type(1);
        seance1.setSemaine(22);
        String date = "2020-05-22";
        seance1.setDate(Date.valueOf(date));
        String t1 = "16:40:00";
        seance1.setHeure_Debut(Time.valueOf(t1));
        String t2 = "18:37:00";
        seance1.setHeure_Fin(Time.valueOf(t2));
        System.out.println(seance1.getHeure_Fin());
        seance1.setEtat(2);
        
        SeanceDAO seanceDao = new SeanceDAO();
        
        seanceDao.update(seance1);
        //Utilisateur utilisateur = utilisateurDao.find(1);
        //System.out.println("Utilisateur N°" + utilisateur1.getId() + "  - " + utilisateur1.getNom() + " " + utilisateur1.getPrenom());
        

        //System.out.println("\n********************************\n");*/
        //PageConnexion accueil = new PageConnexion();
        //RechercheSeance seance = new RechercheSeance();
        AjoutSeance addseance = new AjoutSeance();
        //MenuEtudiant menu = new MenuEtudiant();
       /*SeanceEnseignantDAO seance = new SeanceEnseignantDAO() {
            @Override
            public SeanceEnseignant find(int id) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        int i = seance.testenseignantvalide(15,3);
        
        System.out.println(i);*/
        
   /*String date = "2020-05-22";
      

    

    Calendar calDe = Calendar.getInstance(Locale.FRENCH);       
    calDe.setTime(Date.valueOf(date));


    System.out.println( "FR: " + calDe.get( Calendar.WEEK_OF_YEAR ) );*/
       
            }
    
}
