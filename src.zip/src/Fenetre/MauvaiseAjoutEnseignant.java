/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fenetre;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author PabloMontels, Enguerran Martinet & Gauthier Bouchenoire
 */
public class MauvaiseAjoutEnseignant extends JFrame implements ActionListener{
    
    private final JButton ok;
    private final JPanel p1, p2, p3;
    private final JLabel erreur;
    private final JTextArea id;
    
    public MauvaiseAjoutEnseignant(int seance_id){
    
        super("Erreur d'ajout d'enseignant");
        
        // mise en page (layout) de la fenetre visible
        setLayout(new BorderLayout());
        setBounds(0, 0, 300, 150);
        setResizable(true);
        setVisible(true);
        
        //creation des bouttons
        ok = new JButton("Continuer");
        
        id = new JTextArea(""+seance_id);
        
        // creation des labels
        erreur = new JLabel("Erreur: Mauvaise saisie d'enseignant", JLabel.CENTER);
        
        // creation des panneaux
        p1 = new JPanel();
        p1.setLayout(new GridLayout(1, 1));
        p2 = new JPanel();
        p2.setLayout(new GridLayout(1, 1));
        p3 = new JPanel();
        p3.setLayout(new GridLayout(1, 1));
        
        p1.add(erreur);
        p2.add(ok);
        p3.add(id);
        
        p3.setVisible(false);
        
        ok.addActionListener(this);
        
        //mise en place des panels
        add("North", p1);
        add("South", p2);
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent evt) {
                System.exit(0); // tout fermer												System.exit(0); // tout fermer
            }
        });
    }

    public void actionPerformed(ActionEvent evet) {
        Object source = evet.getSource();
         if (source == ok) {
             setVisible(false);
             AjoutEnseignant con = new AjoutEnseignant(Integer.parseInt(id.getText()));
         }
    
}
}
